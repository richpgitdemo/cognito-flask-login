# This python program prompts the user for two integers 
# and prints a formatted string of the response to the user.

# Get first integer from user
number1 = input("Please enter your first integer: ")

# Get second integer from user
number2 = input("Please enter your second integer: ")

# Calculate the product of two inputs
product = int(number1) * int(number2)

# Print out the result
print(f"The product of your integers is {product}.")